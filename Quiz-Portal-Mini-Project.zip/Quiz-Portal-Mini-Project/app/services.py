from sqlalchemy.orm.session import sessionmaker
from app.models import QuestionMaster, QuizInstance, QuizMaster, QuizQuestions, UserMaster, UserResponses, UserSession
from app import db
import uuid
from flask import session
import datetime
from typing import List

"""
[Services Module] Implement various helper functions here as a part of api
                    implementation using MVC Template
"""
def create_user(**kwargs):
    print(kwargs)
    try:
        user=UserMaster(
            name=kwargs['name'],
            username=kwargs['username'],
            password=kwargs['password'],
            is_admin=kwargs['is_admin']
            )
        db.session.add(user)
        db.session.commit()
    except Exception as e:
        raise e

def check_user_session_is_active_after_login(user_id):
    try:
       user_session=UserSession.query.filter_by(user_id=user_id,is_active=1).first()
       if user_session:
           return user_session.is_active,user_session.session_id
       else:
           return 0,0
    except Exception as e:
        raise e

def check_user_session_is_active(sess_id):
    try:
       user_session_check=UserSession.query.filter_by(session_id=sess_id).first()
       print("user session check")
       if user_session_check:
           return user_session_check.is_active,user_session_check.user_id
       else:
           return 0,0
    except Exception as e:
        raise e

def check_if_admin(user_id):
    try:
        user_admin = UserMaster.query.filter_by(id=user_id).first()
        if user_admin:
            print(user_admin)
            if user_admin.is_admin == 1:
                return 1
            else:
                return 0
        else:
            return 0
    except Exception as e:
        raise e

def add_question(**kwargs):
    try:
        print("adding question")
        print(kwargs)
        question=QuestionMaster(question=kwargs['quesitons'],choice1=kwargs['choice1'],choice2=kwargs['choice2'],choice3=kwargs['choice3'],choice4=kwargs['choice4'],marks=kwargs['marks'],remarks=kwargs['remarks'],answer=kwargs['answer'])
        db.session.add(question)
        db.session.commit()
    except Exception as e:
        print(e)
        raise e

def login_user(**kwargs):
    try:
        user=UserMaster.query.filter_by(username=kwargs['username'],password=kwargs['password']).first()
        print(user)
        if user:
            print('logged in')
            is_active,session_id=check_user_session_is_active_after_login(user.id)
            if not is_active:
                session_id=uuid.uuid4()
                user_session=UserSession(user.id,session_id)
                db.session.add(user_session)
                db.session.commit()

            else:
                session['session_id']=session_id

            session['session_id']=session_id
            print(session_id)
            return True,session_id
        else:
            return False,None
    except Exception as e:
        raise e

def logout_user(sess_id):
    try:
        print(1)
        session= UserSession.query.filter_by(session_id=sess_id,is_active=1)
#
        print(2)
        if session:
            print("hello")
    #        user_session = UserSession(id=session.id,user_id=session.user_id)
    #        print(user_session)
            session.update(dict(is_active=0,updated_ts=datetime.datetime.utcnow()))
       #     db.session.update(session)
            print(3)
            db.session.commit()
            print(4)
            return True
        else:
            return False
    except Exception as e:
        raise e

def list_questions():
    questions = QuestionMaster.query.all()

def create_quiz(**kwargs):
    try:
        quiz=QuizMaster(
            kwargs['quiz_name'],
            )
        db.session.add(quiz)
        db.session.commit()
        for i in kwargs['question_ids']:
            quiz_ques=QuizQuestions(quiz_id=quiz.id,question_id=i)
            db.session.add(quiz_ques)
            db.session.commit()

    except Exception as e:
        raise e

def assign_quiz(**kwargs):
    try:
        quiz=QuizInstance(
            quiz_id=kwargs['quiz_id'],
            user_id=kwargs['user_id']
        )
        db.session.add(quiz)
        db.session.commit()
    except Exception as e:
        raise e

def assigned_quiz(user_id):
    try:
        quiz=QuizInstance.query.filter_by(user_id=user_id)
        if quiz:
            quizs=[]
            for i in quiz:
                quizs.append({'quiz_id':i.quiz_id,'is_submitted':i.is_submitted,'score_acheived':i.score_acheived})
            return quizs
    except Exception as e:
        raise e