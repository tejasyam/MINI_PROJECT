from email.policy import default
from marshmallow import Schema, fields, base

class APIResponse(Schema):
    message = fields.Str(default = "Success")

class SignUpRequest(Schema):
    username = fields.Str(default = "username")
    password = fields.Str(default = "password")
    name = fields.Str(default = "name")
    is_admin = fields.Int(default = 0)

class LoginRequest(Schema):
    username=fields.Str(default="username")
    password=fields.Str(default="password")

class LogoutRequest(Schema):
    session_id=fields.Str(default="session_id")

class QuestionsRequest(Schema):
    session_id=fields.Str(default="session_id")

class ListQuestionsResponse(Schema):
    questions=fields.List(fields.Dict())

class AddQuestionRequest(Schema):
    session_id=fields.Str(default="sesison_id")
    quesitons=fields.Str(default="question")
    choice1=fields.Str(default="choice1")
    choice2=fields.Str(default="choice2")
    choice3=fields.Str(default="choice3")
    choice4=fields.Str(default="choice4")
    marks=fields.Int(default=0)
    remarks=fields.Str(default="remarks")
    answer=fields.Int(default=0)

class CreateQuizRequest(Schema):
    session_id= fields.Str(default="session_id")
    quiz_name=fields.Str(default="quiz_id")
    question_ids=fields.List(fields.String)

class AssignQuizRequest(Schema):
    session_id=fields.Str(default="session_id")
    quiz_id=fields.Str(default="quiz_id")
    user_id=fields.Str(default="user_id")

class ViewQuizRequest(Schema):
    session_id=fields.Str(default="session_id")
    quiz_id=fields.Str(default="quiz_id")

class AssignedQuizRequest(Schema):
    session_id=fields.Str(default="session_id")

class ListQuizs(Schema):
    quizs=fields.List(fields.Dict())

class ViewAllQuizRequest(Schema):
    session_id=fields.Str(default="session_id")

class ListViewAllQuiz(Schema):
    quizs=fields.List(fields.Dict())

class ViewQuiz(Schema):
    quiz_questions=fields.List(fields.Dict())