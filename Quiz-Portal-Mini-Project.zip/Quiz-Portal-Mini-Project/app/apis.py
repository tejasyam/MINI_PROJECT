from email import message
from random import choices
from app.models import *
from app import *
from flask_restful import Resource, request
from flask_apispec.views import MethodResource
from flask_apispec import marshal_with, doc, use_kwargs
from app.schemas import *
from app.services import *



#  Signup API
class SignUpAPI(MethodResource, Resource):
    @doc(description='Sign Up API', tags=['SignUp API'])
    @use_kwargs(SignUpRequest, location=('json'))
    @marshal_with(APIResponse)  # marshalling
    def post(self, **kwargs):
        try:
            create_user(**kwargs)
            return APIResponse().dump(dict(message='User is successfully registered')), 201
        except Exception as e:
            return APIResponse().dump(dict(message=f'Not able to Register User : {str(e)}')), 400


api.add_resource(SignUpAPI, '/signup')
docs.register(SignUpAPI)

# login API
class LoginAPI(MethodResource, Resource):
    @doc(description='Login API', tags=['Login API'])
    @use_kwargs(LoginRequest, location=('json'))
    @marshal_with(APIResponse)  # marshalling
    def post(self, **kwargs):
        try:
            is_logged_in, session_id = login_user(**kwargs)
            if is_logged_in:
                return APIResponse().dump(dict(message=f'User is successfully logged in and created session'))
            else:
                return APIResponse().dump(dict(message='User not found')), 404
        except Exception as e:
            print(str(e))
            return APIResponse().dump(dict(message=f'Not able to login User: {str(e)}'))


api.add_resource(LoginAPI, '/login')
docs.register(LoginAPI)

#Logout API
class LogoutAPI(MethodResource, Resource):
    @doc(description='Logout API', tags=['Logout API'])
    @use_kwargs(LogoutRequest, location=('json'))
    @marshal_with(APIResponse)  # marshalling
    def post(self, **kwargs):
        try:
            is_logged_out = logout_user(kwargs['session_id'])
            if is_logged_out:
                return APIResponse().dump(dict(message=f'User is  successfully logged out'))
            else:
                return APIResponse().dump(dict(message='User is not logged in')), 401
        except Exception as e:
            return APIResponse().dump(dict(message=f'Not able to logout User: {str(e)}'))


api.add_resource(LogoutAPI, '/logout')
docs.register(LogoutAPI)



#List Questions request API 
class ListQuestionAPI(MethodResource, Resource):
    @doc(description='List Questions API', tags=['Questions'])
    @use_kwargs(QuestionsRequest, location=('json'))
    @marshal_with(ListQuestionsResponse)  # marshalling
    def post(self, **kwargs):
        try:
            is_active, user_id = check_user_session_is_active(kwargs['session_id'])
#            is_active, user_id = check_user_session_is_active(**kwargs)
       #     user_session=UserSession() #.query.filter_by(session_id=kwargs['session_id']).first()

            print(is_active, user_id)
            if not is_active:
                return APIResponse().dump(dict(message='User is not loggedin')), 404
            is_admin = check_if_admin(user_id)

            if not is_admin:
                return APIResponse().dump(dict(message='User is not admin user')), 401
            questions_list = QuestionMaster.query.all()
            ques=[]
            for i in questions_list:
                ques.append({'id': i.id, 'question': i.question, 'choice1': i.choice1,'choice2': i.choice2, 'choice3': i.choice3, 'choice4': i.choice4,'answer': i.answer, 'marks':i.marks})
            questions=[i.question for i in questions_list]
            return ListQuestionsResponse().dump(dict(questions=ques)), 200
        except Exception as e:
            print(e)
            return APIResponse().dump(dict(message=f'Error in adding question : {str(e)}'))


api.add_resource(ListQuestionAPI, '/list.questions')
docs.register(ListQuestionAPI)

#add question
class AddQuestionAPI(MethodResource, Resource):
    @doc(description='Add Question API', tags=['Questions'])
    @use_kwargs(AddQuestionRequest, location=('json'))
    @marshal_with(APIResponse)  # marshalling
    def post(self, **kwargs):
        try:
            is_active, user_id = check_user_session_is_active(kwargs['session_id'])
            if not is_active:
                return APIResponse().dump(dict(message='User is not logged in')), 404
            is_admin = check_if_admin(user_id)
            if not is_admin:
                return APIResponse().dump(dict(message='User is not admin user')), 401
            add_question(**kwargs)
            return APIResponse().dump(dict(message='Question is successfully added')), 200
        except Exception as e:
            return APIResponse().dump(dict(messge=f'Error in adding question :{str(e)} '))


api.add_resource(AddQuestionAPI, '/add.question')
docs.register(AddQuestionAPI)

# Create Quiz
class CreateQuizAPI(MethodResource, Resource):
    @doc(description='Create Quiz API', tags=['Quiz'])
    @use_kwargs(CreateQuizRequest, location=('json'))
    @marshal_with(APIResponse)  # marshalling
    def post(self, **kwargs):
        try:
            is_active, user_id = check_user_session_is_active(kwargs['session_id'])
            if not is_active:
                return APIResponse().dump(dict(message='User is not logged in')), 404
            is_admin = check_if_admin(user_id)
            if not is_admin:
                return APIResponse().dump(dict(message='User is not the admin user')), 401
            create_quiz(**kwargs)
            return APIResponse().dump(dict(message='Quiz is successfully created')), 200
        except Exception as e:
            raise e

api.add_resource(CreateQuizAPI, '/create.quiz')
docs.register(CreateQuizAPI)

# assign quiz API
class AssignQuizAPI(MethodResource, Resource):
    @doc(description='Assign Quiz API', tags=['Quiz'])
    @use_kwargs(AssignQuizRequest, location=('json'))
    @marshal_with(APIResponse)  # marshalling
    def post(self, **kwargs):
        try:
            is_active, user_id = check_user_session_is_active(kwargs['session_id'])
            if not is_active:
                return APIResponse().dump(dict(message='User is not logged in')), 404
            is_admin = check_if_admin(user_id)
            if not is_admin:
                return APIResponse().dump(dict(message='User is not the admin user')), 401
            assign_quiz(**kwargs)
            return APIResponse().dump(dict(message='Quiz Assigned successfully')), 200
        except Exception as e:
            raise e


api.add_resource(AssignQuizAPI, '/assign.quiz')
docs.register(AssignQuizAPI)

# View quiz request
class ViewQuizAPI(MethodResource, Resource):
    @doc(description='View Quiz API', tags=['Quiz'])
    @use_kwargs(ViewQuizRequest, location=('json'))
    @marshal_with(ViewQuiz)  # marshalling
    def post(self, **kwargs):
        try:
            is_active, user_id = check_user_session_is_active(kwargs['session_id'])
            if not is_active:
                return APIResponse().dump(dict(message='User is not logged in')), 404
         #   check_access = quiz_access_check(user_id,kwargs['quiz_id'])
            print(kwargs['quiz_id'],user_id)
            check_access= QuizInstance.query.filter_by(quiz_id=kwargs['quiz_id'],user_id=user_id).all()
            is_admin = check_if_admin(user_id)
            print(check_access)
            if check_access or is_admin:
                quiz_question_ids = QuizQuestions.query.filter_by(quiz_id=kwargs['quiz_id']).all()
                print("Quiz questions: ",quiz_question_ids)
                questions=[]
                for i in quiz_question_ids:
                    questions.append(i.question_id)
                questions_all = QuestionMaster.query.filter(QuestionMaster.id.in_(questions)).all()
                print(questions_all)
                questions_output=[]
                for i in questions_all:
                    questions_output.append({'Question': i.question, 'choices':[i.choice1,i.choice2,i.choice3,i.choice4]})
                return ViewQuiz().dump(dict(quiz_questions=questions_output)), 200
            if not is_admin:
                return APIResponse().dump(dict(message='User is not the admin and Quiz is not assigned to user')), 401
        except Exception as e:
            raise e

api.add_resource(ViewQuizAPI, '/view.quiz')
docs.register(ViewQuizAPI)

#assigned list of quizs
class ViewAssignedQuizAPI(MethodResource, Resource):
    @doc(description='View Assigned Quiz API', tags=['Quiz'])
    @use_kwargs(AssignedQuizRequest, location=('json'))
    @marshal_with(ListQuizs)  # marshalling
    def post(self, **kwargs):
        try:
            is_active, user_id = check_user_session_is_active(kwargs['session_id'])
            if not is_active:
                return APIResponse().dump(dict(message='User is not logged in')), 404
            quiz=QuizInstance.query.filter_by(user_id=user_id).all()
            if quiz:
                quizs=[]
                for i in quiz:
                    quizs.append({'quiz_id':i.quiz_id,'is_submitted':i.is_submitted,'score_acheived':i.score_acheived})
                return ListQuizs().dump(dict(quizs=quizs)), 200
            
        except Exception as e:
            raise e


api.add_resource(ViewAssignedQuizAPI, '/assigned.quizzes')
docs.register(ViewAssignedQuizAPI)

#View all quiz api
class ViewAllQuizAPI(MethodResource, Resource):
    @doc(description='View All Quiz API', tags=['Quiz'])
    @use_kwargs(ViewAllQuizRequest, location=('json'))
    @marshal_with(ListViewAllQuiz)  # marshalling
    def post(self, **kwargs):
        try:
            is_active, user_id = check_user_session_is_active(kwargs['session_id'])
            if not is_active:
                return APIResponse().dump(dict(message='User is not logged in')), 404
            is_admin = check_if_admin(user_id)
            if not is_admin:
                return APIResponse().dump(dict(message='User is not the admin user')), 401
            quizs_list = QuizMaster.query.all()
            quiz_list=[]
            for i in quizs_list:
                quiz_list.append({'Quiz_id':i.id,'Quiz_name':i.quiz_name})
            return ListViewAllQuiz().dump(dict(quizs=quiz_list)), 200
        except Exception as e:
            raise e

api.add_resource(ViewAllQuizAPI, '/all.quizzes')
docs.register(ViewAllQuizAPI)